![favicon](https://user-images.githubusercontent.com/82651621/157946803-1bc9766f-56e2-4e01-a874-e9989d461e8d.png)

#Author Jutt Badshah Brand

#THIS TOOL FOR FACEBOOK CLONING

#THIS TOOL IS PAID NOT A FREE

#THIS TOOL FILE CLONING AND RANDOM NUMBER CLONING



<Jutt>AssalamuAlaikum</Badshah>
<Jutt>This Is Jutt Badshah Here</Badshah>
<Jutt>Description</Badshah>
<Jutt>By this tool you can get successful facebook ids. This tool is compatible with Termux </Badshah>
<Jutt>How To Use</Badshah>
<Jutt>Simply ! Type These Below Commands In Terminal </Badshah>
<ul>
<h1>installation</h1>
    <li>pkg update</li>
    <li>pkg upgrade</li>
    <li>pkg install python</li>
    <li>pkg install git</li>
    <li>pip install requests</li>
    <li>pip install mechanize</li>
    <li>pip install bs4 futures</li>
    <li>rm -rf $HOME/JuttBadshah
    <li>git clone https://github.com/SHOOTER-MAKER/JuttBadshah</li>
    <li>cd $HOME/JuttBadshah</li>
    <li>python Juttbrand.py</li>
</ul>
<h1>Usage</h1>
<li>cd $HOME/JuttBadshah</li>
<li>python Juttbrand.py</li>
</ul>
<h1>My Contact Links</h1>
<p>Personal Chat Whatsapp <a href="https://bit.ly/3qANBWS" target="_blank">Click</a>.</p>
<p>Whatsapp Group <a href="https://chat.whatsapp.com/D3Q3WpXWWbv4klHfVGZ4JK" target="_blank">Click</a>.</p>
</ul>
<h1>Disclaimer</h1>
<p>This Tool Is For Educational Purpose Only.Iam Not Responsible For Any Kind Of Lose By This Script.Use It On Your Own Risk</p>
